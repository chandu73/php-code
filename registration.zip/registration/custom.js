 
/*const form =document.getElementById("regform");

console.log(form)	

const fullname =document.getElementById("fname");
console.dir(fname)

const email =document.getElementById("email");
//alert("Hello! I am an alert box!!");

const password =document.getElementById("password");
console.log(password)

form.addEventListener('submit',(e) =>{
	//e.preventDefault(); 
	//console.log(e);
	
});	

function validate(){
	let fnamevalue=fname.value.trim()
	let emailvalue=email.value.trim()
	let paswwordvalue=password.value.trim()
	
	
	if(fnamevalue===''){
		alert('fullname cant be empty')
		console.log(error)
	}
	console.log(fullname)
}
*/
function validateForm() {
  let name = document.forms["regform"]["fname"].value;
  let email = document.forms["regform"]["email"].value;
  if (name == "") {
    alert("Name must be filled out");
    return false;
  }
  if (email == "") {
    alert("email must be filled out");
    return false;
  }
  console.log(ffff)
}

