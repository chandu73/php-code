<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>Registration system PHP and MySQL</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  
</head>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script> 
<script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.11.1/jquery.validate.min.js"></script> 
<script>  
$(document).ready (function () {  
 $('#regform').submit (function (e) {  
    e.preventDefault();  
    var first_name = $('#fname').val();   
    var email = $('#email').val();  
    var password = $('#password').val();   
  $(".error").remove();  
if (first_name.length < 1) {  
      $('#fname').after('<span class="error">This field is required</span>');  
    }  
     
    if (email.length < 1) {  
      $('#email').after('<span class="error">This field is required</span>');  
    } else {  
      var regEx = /^[A-Z0-9][A-Z0-9._%+-]{0,63}@(?:[A-Z0-9-]{1,63}\.){1,125}[A-Z]{2,63}$/;  
      var validEmail = regEx.test(email);  
      if (!validEmail) {  
        $('#email').after('<span class="error">Enter a valid email</span>');  
      }  
    }  
    if (password.length < 8) {  
      $('#password').after('<span class="error">Password must be at least 8 characters long</span>');  
    }  
  });  
  $('form[id="regform"]').validate({  
    rules: {  
      fname: 'required',  
      email: {  
        required: true,  
        email: true,  
      },  
      passsword: {  
        required: true,  
        minlength: 8,  
      }  
    },  
    messages: {  
      fname: 'This field is required',    
      password: {  
        minlength: 'Password must be at least 8 characters long'  
      }  
    },  
    submitHandler: function(form) {  
      form.submit();  
    }  
  });  
});  
</script> 
 
<body>
  <div class="header">
  	<h2>Sign Up</h2>
  </div>
	
  <form id ="regform" method="post" action="">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label>Full name </label>
  	  <input id="fname" type="text" name="fullname" value="">
	  
  	</div>
  	<div class="input-group">
  	  <label>Email *</label>
  	  <input id="email" type="email" name="email" value="">
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input id="password" type="password" name="password_1" autocomplete="on">
  	</div>
  	<div class="input-group">
  	  <label>Confirm password</label>
  	  <input id="cpassword" type="password" name="password_2" autocomplete="on">
  	</div>
  	<div class="input-group">
  	  <button id="submit" type="submit" class="btn" name="reg_user">CREATE ACCOUNT</button>
  	</div>
  	<p>
  		Have an account? <a href="login.php">Sign in</a>
  	</p>

  </form>
</body>
</html>